<?php 
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Ydisk extends CI_Controller {

	function __construct(){
		    parent::__construct();
	        $this->load->model('CsdjDB');
	        $this->load->model('CsdjAdmin');

            //此处为接口密码
            $this->ypass='123456';
	}

    //百度直链同步接口
	public function index()
	{

            if($_GET['ac']=='list'){
			     $sqlstr="SELECT CS_ID,CS_Name FROM ".CS_SqlPrefix."class where CS_SID=1";
			     $result=$this->db->query($sqlstr);
			     foreach ($result->result() as $row) {
                      echo '<option id="cids_'.$row->CS_ID.'" value="'.$row->CS_ID.'">'.$row->CS_Name.'</option>';
			     }
				 exit;
			}

            $pass = $this->security->xss_clean($this->input->post('pass', TRUE));
            if($this->ypass=='123456' || $pass!=$this->ypass) exit('10001');

            $data['cs_name'] = substr($this->input->post('name', TRUE),0,-4);
            $data['cs_cid'] = intval($this->input->post('cid', TRUE));
            $data['cs_yid'] = intval($this->input->post('yid', TRUE));
            $data['cs_pid'] = intval($this->input->post('pid', TRUE));
            $data['cs_dx']  = intval($this->input->post('dx', TRUE));
            $data['cs_yz']  = intval($this->input->post('yz', TRUE));
            $data['cs_sc']  = intval($this->input->post('sc', TRUE));
            $data['cs_playurl'] = $this->input->post('url', TRUE);
            $data['cs_downurl1'] = $data['cs_playurl'];

            if(empty($data['cs_name'])) exit('10002');
            if(empty($data['cs_playurl'])) exit('10003');
            if($data['cs_cid']==0) $data['cs_cid']=1;
            if($data['cs_yid']==0) $data['cs_yid']=0;
            if($data['cs_pid']==7) $data['cs_pid']=0;

			$row=$this->db->query("SELECT CS_ID FROM ".CS_SqlPrefix."dance where CS_PlayUrl='".$data['cs_playurl']."'")->row();
			if($row){
                 exit('10006');
			}

            $data['cs_user']     = "admin";
            $data['cs_uid']      = 1;
            $data['cs_addtime']  = date('Y-m-d H:i:s');
            $res=$this->CsdjDB->get_insert('dance',$data);
            if($res>0){
                 exit('10005');
            }else{
                 exit('10004');
            }
	}

}
