<?php 
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Ydisk extends CI_Controller {

	function __construct(){
		    parent::__construct();

            //�˴�Ϊ�ӿ�����
            $this->ypass='123456';
	}

    //�ٶ�ֱ��ͬ���ӿ�
	public function index()
	{

            if($_GET['ac']=='list'){
			     $sqlstr="SELECT id,name FROM ".CS_SqlPrefix."dance_list where yid=0";
			     $result=$this->db->query($sqlstr);
			     foreach ($result->result() as $row) {
                      echo '<option value="'.$row->id.'">'.$row->name.'</option>';
			     }
				 exit;
			}

            $pass = $this->input->post('pass', TRUE);
            if($this->ypass=='123456' || $pass!=$this->ypass) exit('10001');

            $data['name'] = substr(get_bm($this->input->post('name',TRUE)),0,-4);
            $data['cid'] = intval($this->input->post('cid', TRUE));
            $data['yid'] = intval($this->input->post('yid', TRUE));
            $data['dx']  = intval($this->input->post('dx', TRUE));
            $data['purl'] = get_bm($this->input->post('url', TRUE));
            $data['durl'] = $data['purl'];

			$row=$this->db->query("SELECT id FROM ".CS_SqlPrefix."dance where purl='".$data['purl']."'")->row();
			if($row){
                 exit('10006');
			}

            if(empty($data['name'])) exit('10002');
            if(empty($data['purl'])) exit('10003');
            if($data['cid']==0) $data['cid']=1;

            $data['uid']      = 1;
            $data['addtime']  = time();
            $res=$this->CsdjDB->get_insert('dance',$data);
            if($res>0){
                 exit('10005');
            }else{
                 exit('10004');
            }
	}

}
